DSH Mini v1.2.0 — 手机桥插件发行包
=====================================

安装（PowerShell，仓库根目录执行）：
  pwsh scripts/install.ps1
  或指定安装目录：
  pwsh scripts/install.ps1 -Target "C:\Program Files\DSH Desktop\resources\app"

装完重启 DSH Desktop。之后：
  1. DSH 设置 → 「DSH Mini 手机桥」→ 开启「局域网网关」（DSH web 需 --host 0.0.0.0 才能被手机访问）
  2. 点侧栏左下角「手机连接」图标 → 弹二维码
  3. 手机装 DSH Mini APK（source/apk/ 工程，构建见 apk/README-APK.md）内扫码，
     或手机浏览器开 http://<电脑IP>:<端口>/dsh-mini/ 设置页扫码

详细文档：README.md / SPEC.md